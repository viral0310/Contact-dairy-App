import 'package:lab_work_14_3/resurces/text_color.dart';

class Global {
  static List<Contact> allContacts = [];
}
